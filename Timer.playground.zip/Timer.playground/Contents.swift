import UIKit

for index in -300...10 {
    print("\(index) times 10 is \(index - 10)")
}

let timer = 300
if timer == 300 {
print(" TIME IS UP")
} else {
    print ("START TIMER")
}
